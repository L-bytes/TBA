library(ggplot2)

## see names of available themes
names(ggprism_data$themes)

## preview a theme
preview_theme("floral")
