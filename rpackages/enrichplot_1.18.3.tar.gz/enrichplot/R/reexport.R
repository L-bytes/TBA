##' @importFrom ggplot2 ggtitle
##' @export
ggplot2::ggtitle

##' @importFrom ggplot2 facet_grid
##' @export
ggplot2::facet_grid

##' @importFrom aplot plot_list
##' @export
aplot::plot_list

