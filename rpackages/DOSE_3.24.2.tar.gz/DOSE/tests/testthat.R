library(testthat)
library(DOSE)

test_check("DOSE")

