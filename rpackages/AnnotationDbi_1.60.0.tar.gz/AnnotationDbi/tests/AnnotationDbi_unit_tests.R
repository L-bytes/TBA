require("AnnotationDbi") || stop("unable to load AnnotationDbi package")

AnnotationDbi:::.test()
