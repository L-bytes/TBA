test_that("HDOANCESTOR", {
    aa <- length(as.list(HDOANCESTOR))
    expect_true(aa > 0)
})
