library(testthat)
library(HDO.db)
test_check("HDO.db")
