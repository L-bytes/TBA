.test <- function() BiocGenerics:::testPackage("KEGGREST")
