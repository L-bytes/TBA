#ifndef __pivot_declarations_h__

#define __pivot_declarations_h__

SEXP qorder(SEXP data);

#endif


