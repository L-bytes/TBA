library(testthat)
library(ibb)

test_check("ibb")
