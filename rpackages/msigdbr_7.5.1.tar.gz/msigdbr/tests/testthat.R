library(testthat)
library(msigdbr)

test_check("msigdbr")
