# msigdbr 7.5.1

* Based on MSigDB v7.5.1 release.

# msigdbr 7.4.1

* Based on MSigDB v7.4 release.
* Added Ensembl gene IDs to the returned gene sets.

# msigdbr 7.2.1

* Based on MSigDB v7.2 release.
* Added more annotation fields to the returned gene sets.
* Added `msigdbr_species()` as an alternative to `msigdbr_show_species()`.
* Added `msigdbr_collections()`.

# msigdbr 7.1.1

* Based on MSigDB v7.1 release.
* Increased ortholog prediction stringency.

# msigdbr 7.0.1

* Based on MSigDB v7.0 release.
* Fixed output when selecting multiple collections.

# msigdbr 6.2.1

* Based on MSigDB v6.2 release.

# msigdbr 6.1.1

* Based on MSigDB v6.1 release.
* Initial CRAN submission.
