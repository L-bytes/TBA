library(testthat)
library(babelgene)

test_check("babelgene")
