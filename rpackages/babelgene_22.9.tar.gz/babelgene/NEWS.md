# babelgene 22.9

* Updated the database.
* Added a check for NAs in input genes (#3).

# babelgene 22.3

* Updated the database.
* Fixed the minimum support filter.

# babelgene 21.4

* Initial CRAN submission.
