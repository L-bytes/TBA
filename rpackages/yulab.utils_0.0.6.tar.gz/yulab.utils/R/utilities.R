`%||%` <- function(a, b) ifelse(is.null(a), b, a)


