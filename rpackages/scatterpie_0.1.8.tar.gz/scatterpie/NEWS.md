# scatterpie 0.1.8

+ improve the legend of pie radius (2022-09-03, Sat, #35)

# scatterpie 0.1.7

+ import `get_aes_var` from ggfun instead of rvcheck (2021-08-20)

# scatterpie 0.1.6

+ fixed R check by suggesting rmarkdown package

