library(testthat)
library(ggtree)

test_check("ggtree")
